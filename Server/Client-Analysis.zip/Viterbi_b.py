from math import *
# Define path object as a cluster of:
#     cumulative Hamming distance (d), and
#     cumulative output message (w)
class path(object):
    def __init__(self):
        self.d = 0
        self.w = []
    def __str__(self):
        return str(' Distance: '+str(self.d)+' Message: '+str(self.w))
    def __repr__(self):
        return str(' Distance: '+str(self.d)+' Message: '+str(self.w))

# Efficiently convert strings into indices
def let2i(letters):
    i = 0
    for letter in letters:
        i <<= 5
        if ord('a')<=ord(letter)<=ord('z'):
            i += ord(letter)-ord('a')
        elif letter == '*':
            i += 26
    return i

# Binary codeword to index
def bin2i(codeword):
    i = 0
    for bit in codeword:
        i <<= 1
        i += bit
    return i

# Get Hamming desitance between two code words of the same length
def HamDist(word1,word2):
    dist = 0
    result = word1^word2
    for i in range(0,5):
        dist += result & 1
        result >>= 1
    return dist

# Make two paths equivalent, while keeping them seperate
def assignPath(newPath,Path):
    newPath.d = Path.d
    newPath.w = Path.w

# Decode a binary message______________________________________________________________________________
def decode(w_in, pe, letterBook, alphabet = 'abcdefghijklmnopqrstuvwxyz', print_on=0):

    # State nodes: for Viterbi. Each state corresponds to a letter in the alphabet.
    # Prefixes: Used for determining branches from previous state nodes to current state node.

    # Get logs of probability of error and no error, for probability calculation. One error for each possible Hamming
    # distance.
    if pe == 0:
        peVector = [0] + [2.0 ** 72] * 5
    elif pe == 1:
        peVector = [2.0 ** 72] + [0] * 5
    else:
        peVector = [0] * (6)
        for i in range(0, 6):
            peVector[i] = -log(pe ** i * (1 - pe) ** (5 - i))

    # Initialize lists of paths (one entry for each state)
    paths = [0]*len(alphabet)
    newPaths = [0]*len(alphabet)
    output = bin2i(w_in[0:5])
    for state in range(0,len(alphabet)):
        paths[state] = path()
        paths[state].w = [state]
        paths[state].d = letterBook[0][let2i(alphabet[state])] + peVector[HamDist(state,output)]
        newPaths[state] = path()
        newPaths[state].w = [state]
        newPaths[state].d = letterBook[0][let2i(alphabet[state])] + peVector[HamDist(state,output)]

    # Decode message using Viterbi Algorithm
    for i in range(5,len(w_in),5):
        # Take output from one iteration of the loop from the convolution encoding method
        output = bin2i(w_in[i:i+5])
        # Apply Viterbi starting from each of the 4 states
        for state in range(0,len(alphabet)):
            # Get current state, and:
            #     1. Get the two possible previous states by prepending 0 or 1 to current state (to get a three-some
            #            for the convolution function above)
            #     2. Get the output of each of the two possible previous states (using convolution function)
            #     3. Get the hamming distance between the previous state output and the message output
            #     4. Whoever's distance is lowest, get that state's path, and prepend it to the current state
            #            (implied in this step is incrementing cumulative Hamming distance, resetting current state,
            #            and appending second bit in current state to cumulative output message)

            # For inRate > 1 . . .
            # for each state, find the min weight path in a loop. The path with the lowest weight (cumulative Hamming
            # distance) gets prepended to the state node.

            minPath = [0, inf, 0]  # (min path distance, min cumulative distance, previous state node)
            for prefix in range(0,len(alphabet)):
                pathDist = letterBook[1][let2i(alphabet[prefix]+alphabet[state])]
                pathCumDist = pathDist + paths[prefix].d
                if pathCumDist < minPath[1]:
                    minPath[0] = pathDist
                    minPath[1] = pathCumDist
                    minPath[2] = prefix
            assignPath(newPaths[state], paths[let2i(alphabet[minPath[2]])])
            newPaths[state].w = [state] + newPaths[state].w
            newPaths[state].d += minPath[0] + peVector[HamDist(output,state)]

        # Set previous states with current states
        for state in range(0,len(alphabet)):
            assignPath(paths[state],newPaths[state])

    # Display all 4 paths
    if print_on == 1:
        for i in range(0,len(states)):
            print(paths[i])

    # Get and return message from minimum distance path
    message_out = ''
    w = paths[let2i('u')].w
    for i in range(0,len(w)-1):
        message_out += alphabet[w.pop()]
    return message_out


