from math import *
from Huffmant import *
from random import *
import statistics
import genPara
import Convolutional_ENC
import Viterbi_a
import Viterbi_b
import Viterbi_c
from GetBinTransitions import GetBinTransitions

import sys
import time
import os.path

# Lin's symbol error rate code - get error rate - I modified it to support unequally lengthed strings
def findErrorRate(messagein, messageout):
    length = len(messagein)
    lendiff = length - len(messageout)
    for i in range(0,lendiff):
        messageout += '*'
    count = 0
    for i in range(length):
        if messagein[i] != messageout[i]:
            count += 1
    return (count/length,lendiff)

# Efficiently convert strings into indices
def let2i(letters):
    i = 0
    for letter in letters:
        i <<= 5
        if ord('a')<=ord(letter)<=ord('z'):
            i += ord(letter)-ord('a')
        elif letter == '*':
            i += 26
    return i

# Binary codeword to index
def bin2i(codeword):
    i = 0
    for bit in codeword:
        i <<= 1
        i += bit
    return i

# Define channel with binary symmetric noise
def UnifNoise(x,pe):
    y = []
    for bit in x:
        y.append(bit^(random()<pe))
    return y

# Define convertor from Huffman code to alphabet
def huffDecode(channel_output, huffBook):
    message = ""
    i_low = 0
    i_hi = 0
    # Get length of longest codeword in huffBook, as an upper limit
    max_len = len(list(huffBook.values())[-1])
    # Decode until the end of the bit stream
    while i_hi < len(channel_output):
        # If codeword too long, there was an error. Declare an erasure, and restart the codeword search from the next
        # bit after lower index. Else, increment the upper index.
        if i_hi - i_low >= max_len:
            i_low += 1
            i_hi = i_low
            print('Erasure')
        else:
            i_hi += 1
        # Search huffBook for the codeword specified by the bits in the channel output bit stream, from the lower index
        # to the upper index. If a match is found, add letter to decoded message, and start search again from the upper
        # index. Otherwise, increase codeword length (by increasing upper index), and restart search.
        for letter in huffBook:
            if huffBook[letter] == channel_output[i_low : i_hi]:
                message += letter
                i_low = i_hi
                break
    return message

# System________________________________________________________________________________________________________________

# Instructions format:  [<model code>,<message_len>,<BSC Epsilon>,<Huffman order>,<inRate>,<alphabet>,
#                           <generator sequence>,<M, number of trials>,<i, packet index>]
# Sample instructions:  ['A',1000,0.01,1,1,'abcdefghijklmnopqrstuvwxyz',[5,7],100,2]
#                       ['B',1000,0.05,1,1,'abcdefghijklmnopqrstuvwxyz',[],150,4]


# Analyze the model
def Analyze(model_sel,message_len,epsilon,Huff_order,inRate,alphabet,genSeq,M):
    # Check inputs
    if model_sel != 'A' and model_sel != 'AB' and model_sel != 'B' and model_sel != 'C':
        return (-1,'Error in model_sel input')
    if (model_sel == 'AB' or model_sel == 'B' or model_sel == 'C') and Huff_order != 0:
        return (-1,'Huff_order should be 0 (fixed-length) for specified model')
    if not (0 <= Huff_order <=2):
        return (-1,'Huff_order is out of bounds')
    if message_len <= 0:
        return (-1,'Message length should not be 0 or negative')
    if inRate <= 0:
        return (-1, 'inRate should not be 0 or negative')
    if (model_sel == 'B' and model_sel == 'C') and inRate != 1:
        return (-1, 'inRate should be 1 for specified model')

    # Define letter to binary mapping
    codeBook = {}
    if Huff_order == 0:
        alphabet_order = int(log(len(alphabet),2)-1)+1
        for i in range(0,len(alphabet)):
            codeword = []
            bits = i
            for j in range(0,alphabet_order):
                codeword.append(bits&1)
                bits >>= 1
            codeBook[alphabet[i]] = codeword[::-1]
    elif Huff_order == 1 or Huff_order == 2:
        codeBook = Huffman.makeHuffDict(Huffman, statistics.letterBook[Huff_order - 1])
    else:
        return (-1,'Error in Huff_order input')

    # Arrange statistics arrays
    if model_sel == 'B' or model_sel == 'AB':
        letterBook = statistics.letterBook
        book = [0, 0]
        book[0] = [2.0 ** 72] * 32
        book[1] = [2.0 ** 72] * 32 ** 2
        for letter in letterBook[0]:
            ptemp = letterBook[0][letter]
            if ptemp == 0:
                ptemp = 2.0 ** 72
            else:
                ptemp = -log(ptemp)
            book[0][let2i(letter)] = ptemp
        for letter in letterBook[1]:
            ptemp = letterBook[1][letter] / letterBook[0][letter[0]]
            if ptemp == 0:
                ptemp = 2.0 ** 72
            else:
                ptemp = -log(ptemp)
            book[1][let2i(letter)] = ptemp
    if model_sel == 'C':
        binTuples = GetBinTransitions(alphabet)
        count = []
        for j in range(0, len(binTuples)):
            if binTuples[j] == 1:
                count.append(2.0 ** 72)
            else:
                count.append(-log(1 - binTuples[j]))
        binTuples = count

    # Run the Model M times and return sum of and sum of squares of symbol error rates
    error_sum = 0
    error_varSum = 0
    for i in range(0,M):
        # Randomly generate message
        message = genPara.genParagraph(message_len)

        # Convert symbol message into bit message
        x = []
        for letter in message:
            x += codeBook[letter]
        if model_sel == 'AB' or model_sel == 'B' or model_sel == 'C':
            x += codeBook['u']

        # Convolution encode message
        if model_sel == 'A' or model_sel == 'AB' or model_sel == 'C':
            x = Convolutional_ENC.conv_ENC(genSeq,x,inRate)

        # Send message through Binary Symmetric Channel (BSC)
        y = UnifNoise(x,epsilon)

        # Decode and invert message
        w = []
        message_out = ''
        # Convolution decode message
        if model_sel == 'A' or model_sel == 'AB':
            w = Viterbi_a.conv_DEC(y, genSeq, inRate)
        # Joint Convolution/Source Statistics decode message
        if model_sel == 'C':
            message_out = Viterbi_c.conv_DEC(y, epsilon, genSeq, binTuples)
        # Source Statistics decode message
        if model_sel == 'B':
            message_out = Viterbi_b.decode(y, epsilon, book, alphabet)
        # Source Statistics decode message
        if model_sel == 'AB':
            message_out = Viterbi_b.decode(w, epsilon, book, alphabet)
        # Fixed-length or Huffman invert message
        if model_sel == 'A':
            if Huff_order > 0:
                message_out = huffDecode(w, codeBook)
            else:
                for i in range(0,len(w),5):
                    message_out += alphabet[bin2i(w[i:i+5])]

        # Get symbol error rate
        error = findErrorRate(message,message_out)[0]
        error_sum += error
        error_varSum += error**2

    # print(message)
    # print(message_out)
    return (error_sum, error_varSum)





