import Analysis
import time

# Parse instructions sent by the server
# Instructions format:  [<model code>,<message_len>,<BSC Epsilon>,<Huffman order>,<inRate>,<alphabet>,
#                           <generator sequence>,<M, number of trials>,<i, packet index>]
# Sample instructions:  ['A',1000,0.01,1,1,'abcdefghijklmnopqrstuvwxyz',[5,7],100,2]
#                       ['B',1000,0.05,0,1,'abcdefghijklmnopqrstuvwxyz',[],150,4]
def instParse(instructions):
    # e.g. inst = ['A',1000,0.01,1,1,'abcdefghijklmnopqrstuvwxyz',[5,7],100,2]
    inst = instructions[::-1]
    inst = list(inst)
    inst.pop()
    inst.pop()
    # e.g. inst = A',1000,0.01,1,1,'abcdefghijklmnopqrstuvwxyz',[5,7],100,2]
    model_sel = inst.pop()
    temp = inst.pop()
    if temp != "'":
        model_sel += temp
        inst.pop()
    inst.pop()
    # e.g. inst = 1000,0.01,1,1,'abcdefghijklmnopqrstuvwxyz',[5,7],100,2]
    numstr = '*'
    while numstr[-1] != ',':
        numstr += inst.pop()
    message_len = int(numstr[1:-1])
    # e.g. inst = 0.01,1,1,'abcdefghijklmnopqrstuvwxyz',[5,7],100,2]
    numstr = '*'
    while numstr[-1] != ',':
        numstr += inst.pop()
    epsilon = float(numstr[1:-1])
    # e.g. inst = 1,1,'abcdefghijklmnopqrstuvwxyz',[5,7],100,2]
    Huff_order = int(inst.pop())
    inst.pop()
    # e.g. inst = 1,'abcdefghijklmnopqrstuvwxyz',[5,7],100,2]
    inRate = int(inst.pop())
    inst.pop()
    # e.g. inst = abcdefghijklmnopqrstuvwxyz',[5,7],100,2]
    alphabet = '*'
    while alphabet[-1] != ',':
        alphabet += inst.pop()
    alphabet = alphabet[2:-2]
    # e.g. inst = [5,7],100,2]
    listind = inst.pop()
    numstr = ''
    genSeq = []
    if model_sel != 'B':
        while listind != ']':
            listind = inst.pop()
            if listind != ']' and listind != ',':
                numstr += listind
            else:
                genSeq.append(int(numstr))
                numstr = ''
    else:
        inst.pop()
    inst.pop()
    # e.g. inst = 100,2]
    numstr = '*'
    while numstr[-1] != ',':
        numstr += inst.pop()
    M = int(numstr[1:-1])
    # e.g. inst = 2]
    numstr = '*'
    while numstr[-1] != ']':
        numstr += inst.pop()
    ip = int(numstr[1:-1])
    # e.g. inst = ''

    Instruction_set = (model_sel, message_len, epsilon, Huff_order, inRate, alphabet, genSeq, M, ip)
    return Instruction_set


# Instructions format:  [<model code>,<message_len>,<BSC Epsilon>,<Huffman order>,<inRate>,<alphabet>,
#                           <generator sequence>,<M, number of trials>,<i, packet index>]
# Sample instructions:  ['A',1000,0.01,1,1,'abcdefghijklmnopqrstuvwxyz******',[5,7],100,2]
#                       ['B',1000,0.05,0,1,'abcdefghijklmnopqrstuvwxyz******',[],150,4]

# Client________________________________________________________________________________________________________________
def run(socket, instruction):
    # Parse instructions
    (model_sel, message_len, epsilon, Huff_order, inRate, alphabet, genSeq, M, ip) = instParse(instruction)

    # Run Analysis
    (error_sum,error_varsum) = Analysis.Analyze(model_sel,message_len,epsilon,Huff_order,inRate,alphabet,genSeq,M)
    packet = str((model_sel, message_len, epsilon, Huff_order, inRate, alphabet, genSeq, M, ip)) + str(error_sum) + ',' + str(error_varsum) + ','

    # Prepare data and send to server
    socket.send(('RESULT' + packet).encode())
    # before sending the next set of data, don't forget to wait until the server is ready to receive
    while socket.recv(1024).decode() != "READY": time.sleep(1)
    socket.send('FINISH'.encode())



# Test code _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
'''
# Parse instructions
#inst = getInstructions()[::-1]
inst = "['A',100,0.05,0,1,'abcdefghijklmnopqrstuvwxyz******',[5,7],1,2]"
#inst = "['B',1000,0.001,0,1,'abcdefghijklmnopqrstuvwxyz******',[],10,4]"
(model_sel, message_len, epsilon, Huff_order, inRate, alphabet, genSeq, M, ip) = instParse(inst)

# Run Analysis
(error_sum, error_varsum) = Analysis.Analyze(model_sel,message_len,epsilon,Huff_order,inRate,alphabet,genSeq,M)
packet = inst + str(error_sum) + ',' + str(error_varsum) + ','
# print(error_sum)
# print(error_varsum)
'''


























