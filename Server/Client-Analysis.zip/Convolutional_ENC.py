# Version 1 -- Xiaofeng Lin
# Version 2 -- Anthony Krause

# Note that for a (n,k,K) convolutional code, n is the input data rate, k is the output symbol rate and K is the
# constraint length. For this function K = memory + 1, k = len(genSeq), and inRate = n. Thus the code
# has code rate k/n = len(genSeq)/inRate

# Run convolutional encoder 1 iteration
def conv_ENC_iter(register, genList):
    output = []
    for i in range(0, len(genList)):
        sum = 0
        for j in range(0, len(genList[i])):
            sum ^= register[j] & genList[i][j]
        output.append(sum)
    #print('Register: ', register)
    #print('EncodedMsg: ', output)
    return output

# Convolutionally encode an entire message. Google how it works. genSeq is the sequence of generator polynomials.
def conv_ENC(genSeq, message, inRate=1):
    # Convert generator sequence from integer type to list type, and find convolutional code memory and rate
    genList = []
    memory = 0
    rate = len(genSeq) # in units bits/source bit
    for i in range(0, rate):
        poly = []
        for digit in format(genSeq[i], 'b'):
            poly.append(int(digit))
        genList.append(poly)

        if len(poly) > memory:
            memory = len(poly)
    memory -= 1

    # Cushion the message with 0's
    #message = [0] * memory + message
    message = [0]*memory + message + [0]*memory

    # Perform convolution encoding
    messageOut = []
    for i in range(0, len(message)-memory, inRate):
        messageOut += conv_ENC_iter(message[i:i+memory+1],genList)

    if i != len(message)-memory-1:
        messageOut += conv_ENC_iter(message[-memory-1:],genList)

    # Restore the input message to its former state before returning the encoded message
    # i.e. remove the extra 0's
    message = message[memory:]
    #message = message[memory:len(message) - len([0] * (memory - 2))]
            # The editor grays 'message' out, but this line is actually changing the orignal list
            # that was passed to the function

    return messageOut













