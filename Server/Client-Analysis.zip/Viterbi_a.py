from math import *
# Define path object as a cluster of:
#     cumulative Hamming distance (d), and
#     cumulative output message (w)
class path(object):
    def __init__(self):
        self.d = 0
        self.w = []
    def __str__(self):
        return str(' Distance: '+str(self.d)+' Message: '+str(self.w))
    def __repr__(self):
        return str(' Distance: '+str(self.d)+' Message: '+str(self.w))

# Run convolutional encoder 1 iteration
def conv_ENC_iter(register, genSeq):
    output = 0
    for poly in genSeq:
        output <<= 1
        result = register & poly
        sum = 0
        while result:
            sum ^= result & 1
            result >>= 1
        output += sum
    return output

# Binary codeword to index
def bin2i(codeword):
    i = 0
    for bit in codeword:
        i <<= 1
        i += bit
    return i

# Get Hamming desitance between two code words of the same length
def HamDist(word1,word2,wordLen):
    dist = 0
    result = word1^word2
    for i in range(0,wordLen):
        dist += result & 1
        result >>= 1
    return dist

# Make two paths equivalent, while keeping them seperate
def assignPath(newPath,Path):
    newPath.d = Path.d
    newPath.w = Path.w

# Decode a convolutionally encoded message______________________________________________________________________________
def conv_DEC(w_in, genSeq, inRate=1, print_on=0):
    # Get generator function rate and memory
    rate = len(genSeq)
    memory = 0
    result = 0
    for poly in genSeq:
        result |= poly
    while result:
        result >>= 1
        memory += 1
    memory -= 1

    # Precalculate convolution encoder outputs
    conv_outputs = []
    for register in range(0,2<<memory):
        conv_outputs.append(conv_ENC_iter(register,genSeq))

    # State nodes: for Viterbi.
    # Prefixes: Used for determining branches from previous state nodes to current state node.
    inRateMask = (1 << inRate)-1

    # Initialize lists of paths (one entry for each state)
    paths = [0]*(1<<memory)
    newPaths = [0]*(1<<memory)
    for state in range(0,1<<memory):
        paths[state] = path()
        newPaths[state] = path()

    # Decode message using Viterbi Algorithm
    for i in range(0,len(w_in),rate):
        # Take output from one iteration of the loop from the convolution encoding method
        output = bin2i(w_in[i:i+rate])
        # Apply Viterbi starting from each of the 4 states
        for state in range(0,1<<memory):  # e.g. 00,01,10,11 for memory 2
            # Get current state, and:
            #     1. Get the two possible previous states by prepending 0 or 1 to current state (to get a three-some
            #            for the convolution function above)
            #     2. Get the output of each of the two possible previous states (using convolution function)
            #     3. Get the hamming distance between the previous state output and the message output
            #     4. Whoever's distance is lowest, get that state's path, and prepend it to the current state
            #            (implied in this step is incrementing cumulative Hamming distance, resetting current state,
            #            and appending second bit in current state to cumulative output message)

            # For inRate > 1 . . .
            # for each state, find the min weight path in a loop. The path with the lowest weight (cumulative Hamming
            # distance) gets prepended to the state node.

            minPath = [0, inf, 0]  # (min path distance, min cumulative distance, previous state node)
            for prefix in range(0,1<<(memory+inRate),1<<memory):  # e.g. 000,100 for memory 2
                pathDist = HamDist(output,conv_outputs[(prefix+state)>>(inRate-1)],rate)
                pathCumDist = pathDist + paths[(prefix + state)>>inRate].d
                if pathCumDist < minPath[1]:
                    minPath[0] = pathDist
                    minPath[1] = pathCumDist
                    minPath[2] = (prefix + state)>>inRate
            assignPath(newPaths[state], paths[minPath[2]])
            newPaths[state].w = [state & inRateMask] + newPaths[state].w
            newPaths[state].d += minPath[0]

        # Set previous states with current states
        for state in range(0,1<<memory):
            assignPath(paths[state],newPaths[state])

    # Display all 4 paths
    if print_on == 1:
        for state in range(0,1<<memory):
            print(paths[state])

    # Get and return message from minimum distance path. 0 index corresponds to state of all zeros.
    return paths[0].w[::-1][:-memory]


